$(function() {

    "use strict";

    //===== Prealoder

    $(window).on('load', function (event) {
        $('.preloader').delay(500).fadeOut(500);
    });


    //===== Sticky

    $(window).on('scroll', function (event) {
        var scroll = $(window).scrollTop();
        if (scroll < 20) {
            $(".header_navbar").removeClass("sticky");
            $(".header_navbar img").attr("src", "assets/images/logo.png");
        } else {
            $(".header_navbar").addClass("sticky");
            $(".header_navbar img").attr("src", "assets/images/logo-dark.png");
        }
    });


    //===== Section Menu Active

    var scrollLink = $('.page-scroll');
    // Active link switching
    $(window).scroll(function () {
        var scrollbarLocation = $(this).scrollTop();

        scrollLink.each(function () {

            var sectionOffset = $(this.hash).offset().top - 73;

            if (sectionOffset <= scrollbarLocation) {
                $(this).parent().addClass('active');
                $(this).parent().siblings().removeClass('active');
            }
        });
    });
    

    //===== close navbar-collapse when a  clicked

    $(".navbar-nav a").on('click', function () {
        $(".navbar-collapse").removeClass("show");
    });

    $(".navbar-toggler").on('click', function () {
        $(this).toggleClass("active");
    });

    $(".navbar-nav a").on('click', function () {
        $(".navbar-toggler").removeClass('active');
    });
    

    //===== Back to top

    // Show or hide the sticky footer button
    $(window).on('scroll', function (event) {
        if ($(this).scrollTop() > 600) {
            $('.back-to-top').fadeIn(200)
        } else {
            $('.back-to-top').fadeOut(200)
        }
    });


    //Animate the scroll to yop
    $('.back-to-top').on('click', function (event) {
        event.preventDefault();

        $('html, body').animate({
            scrollTop: 0,
        }, 1500);
    });


    //=====  WOW active

    var wow = new WOW({
        boxClass: 'wow', //
        mobile: false, // 
    })
    wow.init();

    //===== 



});


 function myFunction() 
    { 
        //alert('jhjhj');
        document.getElementById("item-form").reset(); 
    }

    function editData(a){
       // alert('hello');
         //var y = document.getElementById("name").value;
        alert(a);
    }

    function edit_row(no)
{
 document.getElementById("edit_button"+no).style.display="none";
 document.getElementById("save_button"+no).style.display="block";
    //alert('hello');
 var name=document.getElementById("name"+no);
 var category=document.getElementById("category"+no);
 var firm=document.getElementById("firm"+no);
    //alert('hello');
 var name_data=name.innerHTML;
 //var category_data=category.innerHTML;
 //var firm_data=firm.innerHTML;
    //alert('hello');
    $tr = $(this).closest('tr');
    
                var data = $tr.children("td").map(function () {
                    return $(this).text();
                }).get();
    
                console.log(data);
 name.innerHTML="<input type='text' id='name_text"+no+"' value='"+name_data+"'>";
 //category.innerHTML="<input type='text' id='category_text"+no+"' value='"+category_data+"'>";
 //firm.innerHTML="<input type='text' id='firm_text"+no+"' value='"+firm_data+"'>";
}

function saveData(){
    //use this link for future to save into database;
    //https://www.c-sharpcorner.com/UploadFile/5089e0/update-a-record-from-database-using-textbox-in-javascript1/
    alert('hiiiiiii');
      $.ajax({
        type: "POST",
        url: "index.html",
        data: { name: $("select[name='players']").val()},
        success:function( msg ) {
         alert( "Data Saved: " + msg );
        }
       });
  }